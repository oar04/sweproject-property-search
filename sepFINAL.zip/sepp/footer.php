<div class="copyright-footer">
            <p class="copyright color-text-a">
              &copy; Copyright
              <span class="color-a">FDM Properties</span> All Rights Reserved.
            </p>
          </div>

        </div>
      </div>
    </div>
  </footer>