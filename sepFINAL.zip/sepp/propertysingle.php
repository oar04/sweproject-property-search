<?php
  session_start();
?>

<?php

    $db = mysqli_connect("localhost", "root", "", "login");

    //check GET req id
    if(isset($_GET['id'])){

        $id = $_GET['id'];

        //db query
        $sql = "SELECT * FROM listings WHERE id = $id";
        //get the result
        $result = mysqli_query($db, $sql);

        $property = mysqli_fetch_assoc($result);

        mysqli_free_result($result);
        mysqli_close($db);
    }
?>

<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport">

  <title>FDM Properties - About</title>
  <meta content="" name="description">
  <meta content="" name="keywords">

  <!-- Favicons -->
  <link href="assets/img/favicon.png" rel="icon">
  <link href="assets/img/apple-touch-icon.png" rel="apple-touch-icon">

  <!-- Google Fonts -->
  <link href="https://fonts.googleapis.com/css?family=Poppins:300,400,500,600,700" rel="stylesheet">

  <!-- Vendor CSS Files -->
  <link href="assets/vendor/animate.css/animate.min.css" rel="stylesheet">
  <link href="assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <link href="assets/vendor/bootstrap-icons/bootstrap-icons.css" rel="stylesheet">
  <link href="assets/vendor/swiper/swiper-bundle.min.css" rel="stylesheet">

  <!-- Template Main CSS File -->
  <link href="assets/css/style.css" rel="stylesheet">

  <!-- =======================================================
  * Template Name: EstateAgency - v4.1.0
  * Template URL: https://bootstrapmade.com/real-estate-agency-bootstrap-template/
  * Author: BootstrapMade.com
  * License: https://bootstrapmade.com/license/
  ======================================================== -->
</head>

<body>

  <!--  <footer> -->
 <?php
    include "includes/navbar.php"
?>
<!-- End  Footer -->

  <main id="main">

  <body>
  <body>
        <div class="copyright-footer">
            <p class="copyright color-text-a">
              &copy; Copyright
              <span class="color-a">FDM Properties</span> All Rights Reserved.
            </p>
          </div>
        <div class="copyright-footer">
                <?php if($property): ?>
                <?php $imageName = $property['image']; ?>
                <?php $id = $property['id']; ?>
                <?php echo "<img src='images/$imageName'>"; ?>
                <p class="color-a"><?php echo htmlspecialchars($property['address']); ?></p>
                <p><?php echo htmlspecialchars($property['city']); ?></p>
                <p><?php echo htmlspecialchars($property['postcode']); ?></p>
                <p><?php echo htmlspecialchars($property['rent']); ?></p>
                <p><?php echo htmlspecialchars($property['description']); ?></p>

                <?php
                
                
                if (isset($_SESSION['admin'])){ ?>
                        <form action = 'delete.php' method = 'post'>
                                <input type = 'hidden' name = 'id-delete' value =<?php echo $id; ?>>
                                <input type = 'submit' name = 'delete' value = 'Delete'>
                                </form>
                        

                <?php } else{ echo ' ';} ?>

                <?php endif; ?>
        </div>
  </body>

    

    
  </main><!-- End #main -->

   <!-- ======= Footer ======= -->
  <section class="section-footer">
    <div class="container">
      <div class="row">
        <div class="col-sm-12 col-md-4">
          <div class="widget-a">
            <div class="w-header-a">
              <h3 class="w-title-a text-brand"> FDM Properties</h3>
            </div>
            <div class="w-body-a">
              <p class="w-text-a color-text-a">
                Thank you for visting FDM Properties. Any suggestions for how we can 
                run our website better will be highly appretiated
              </p>
            </div>
            <div class="w-footer-a">
              <ul class="list-unstyled">
                <li class="color-a">
                  <span class="color-text-a">Phone .</span> contact@example.com
                </li>
                <li class="color-a">
                  <span class="color-text-a">Email .</span> +54 356 945234
                </li>
              </ul>
            </div>
          </div>
        </div>
    
  <!--  <footer> -->
  <?php
    include "includes/footer.php"
?>
<!-- End  Footer -->

  <div id="preloader"></div>
  <a href="#" class="back-to-top d-flex align-items-center justify-content-center"><i class="bi bi-arrow-up-short"></i></a>

  <!-- Vendor JS Files -->
  <script src="assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
  <script src="assets/vendor/php-email-form/validate.js"></script>
  <script src="assets/vendor/swiper/swiper-bundle.min.js"></script>

  <!-- Template Main JS File -->
  <script src="assets/js/main.js"></script>

</body>

</html>

