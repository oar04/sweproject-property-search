<?php

    session_start();
    if (isset($_SESSION['loggedIn']) && $_SESSION['loggedIn'] == true) {
    echo "logged in";
    }
    //if a user tries to access this page to enter a blog post without being logged in, it will automatically redirect them to the login page
    else {
        header("Location: login-user.php");

    }

?>

<?php
    $msg = "";
    //if upload button is pressed
    if(isset($_POST["upload"])){
        //path to store uploaded files
        $target = "images/".basename($_FILES['image']['name']);
        
        //connect to database
        $db = mysqli_connect("localhost", "root", "", "login");

        //get submitted data from the form
        $image = $_FILES['image']['name'];
        $address = $_POST['address'];
        $city = $_POST['city'];
        $postcode = $_POST['postcode'];
        $rent = $_POST['rent'];
        $description = $_POST['text'];
        $area = $_POST['area'];
        $bed = $_POST['bed'];
        $bath = $_POST['bath'];
        $garage = $_POST['garage'];

        $sql = "INSERT INTO listings (image, address, city, postcode, rent, description, area, bed, bath, garage) VALUES ('$image', '$address', '$city', '$postcode', '$rent', '$description', '$area', '$bed', '$bath', '$garage')";
        mysqli_query($db, $sql); //stores submitted data to db

        //upload images to image folder
        if(move_uploaded_file($_FILES['image']['tmp_name'], $target)){
            $msg = "Successful Upload!";
            header("Location: property.php");
        }
        else{
            $msg = "There was an issue uploading, please try again. If the problem persists please contact a system admin here [add link to chat page]";
        }
        

    }

?>

<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport">

  <title>FDM Properties - About</title>
  <meta content="" name="description">
  <meta content="" name="keywords">

  <!-- Favicons -->
  <link href="assets/img/favicon.png" rel="icon">
  <link href="assets/img/apple-touch-icon.png" rel="apple-touch-icon">

  <!-- Google Fonts -->
  <link href="https://fonts.googleapis.com/css?family=Poppins:300,400,500,600,700" rel="stylesheet">

  <!-- Vendor CSS Files -->
  <link href="assets/vendor/animate.css/animate.min.css" rel="stylesheet">
  <link href="assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <link href="assets/vendor/bootstrap-icons/bootstrap-icons.css" rel="stylesheet">
  <link href="assets/vendor/swiper/swiper-bundle.min.css" rel="stylesheet">

  <!-- Template Main CSS File -->
  <link href="assets/css/style.css" rel="stylesheet">

  <!-- =======================================================
  * Template Name: EstateAgency - v4.1.0
  * Template URL: https://bootstrapmade.com/real-estate-agency-bootstrap-template/
  * Author: BootstrapMade.com
  * License: https://bootstrapmade.com/license/
  ======================================================== -->
</head>

<body>

  <!--  <footer> -->
 <?php
    include "includes/navbar.php"
?>
<!-- End  Footer -->
    <body>
    <?php

        // $db = mysqli_connect("localhost", "root", "", "login");
        // $sql = "SELECT * FROM listings";
        // $result = mysqli_query($db, $sql);
        // while($row = mysqli_fetch_array($result)){
        //     echo "<div id='img_div'>";
        //         echo "<img src='images/".$row['image']."'>";
        //         echo "<p>".$row['address']."</p>";
        //         echo "<p>".$row['city']."</p>";
        //         echo "<p>".$row['postcode']."</p>";
        //         echo "<p>".$row['rent']."</p>";
        //         echo "<p>".$row['description']."</p>";
        //     echo "</div>";

        // }

    ?>
        <div class = "form">
            <div class = "upload-listing">
                <form method = "post" action = "uploadListing.php" enctype = "multipart/form-data">
                    <br>
                    <br>
                    <br>
                    <br>
                    <br>
                    <ul style="list-style-type:none;">
                        <input type = "hidden" name = "size" value = "100000">
                        
                        <li><label>image</label></li>
                        <li><input type = "file" name = "image"></li>
                        
                        <li><label>address</label></li>
                        <li><input type = "text" name = "address"></li>
                        
                        <li><label>city</label></li>
                        <li><input type = "text" name = "city"></li>
                        
                        <li><label>postcode</label></li>
                        <li><input type = "text" name = "postcode"></li>
                        
                        <li><label>rent</label></li>
                        <li><input type = "text" name = "rent"></li>
                        
                        <li><label>area</label></li>
                        <li><input type = "text" name = "area"></li>

                        <li><label>beds</label></li>
                        <li><input type = "text" name = "bed"></li>

                        <li><label>baths</label></li>
                        <li><input type = "text" name = "bath"></li>

                        <li><label>garages</label></li>
                        <li><input type = "text" name = "garage"></li>
                        
                        <li><label>description</label></li>
                        <li><textarea name = "text" cols = "50" rows = "4" placeholder = "Listing Description..."></textarea></li>
                        <li><input type = "submit" name = "upload" value = "upload"></li>
                    </ul>
                </form>
            </div>
        </div>
    </body>

    <!--  <footer> -->
 <?php
    include "includes/footer.php"
?>
<!-- End  Footer -->

</html>